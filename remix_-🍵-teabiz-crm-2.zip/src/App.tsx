/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { Topnav } from "./components/Topnav";
import { AnalyticsCards } from "./components/AnalyticsCards";
import { Charts } from "./components/Charts";
import { LeadList } from "./components/LeadList";
import { LeadForm } from "./components/LeadForm";
import { SplashScreen } from "./components/SplashScreen";
import { INITIAL_LEADS } from "./utils";
import type { Lead } from "./types";
import { AnimatePresence } from "motion/react";

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [leads, setLeads] = useState<Lead[]>(INITIAL_LEADS);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const handleAddLead = (newLead: Lead) => {
    setLeads([newLead, ...leads]);
    setIsFormOpen(false);
  };

  const filteredLeads = leads.filter(lead => 
    lead.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <>
      <AnimatePresence>
        {showSplash && <SplashScreen onFinish={() => setShowSplash(false)} />}
      </AnimatePresence>

      <div className={`min-h-screen bg-stone-50 font-sans text-stone-900 selection:bg-emerald-100 selection:text-emerald-900 ${showSplash ? 'hidden' : 'block'}`}>
        <Topnav 
          onAddLead={() => setIsFormOpen(true)} 
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />
        
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <AnalyticsCards leads={leads} />
          <Charts leads={leads} />
          <LeadList leads={filteredLeads} />
        </main>

        <LeadForm 
          isOpen={isFormOpen} 
          onClose={() => setIsFormOpen(false)} 
          onSave={handleAddLead} 
        />
      </div>
    </>
  );
}

