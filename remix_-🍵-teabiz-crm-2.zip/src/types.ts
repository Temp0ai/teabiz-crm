export type LeadStatus = 'New' | 'Contacted' | 'Qualified' | 'Converted' | 'Lost';

export interface Lead {
  id: string;
  name: string;
  businessName: string;
  phone: string;
  email: string;
  status: LeadStatus;
  productInterest: string;
  createdAt: string;
}

export interface AnalyticsData {
  totalLeads: number;
  conversionRate: number;
  activeOpportunities: number;
  revenue: number;
}
