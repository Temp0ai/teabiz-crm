import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function generateId() {
  return Math.random().toString(36).substr(2, 9);
}

export const INITIAL_LEADS = [
  {
    id: "1",
    name: "Rajesh Kumar",
    businessName: "Sunrise Cafe",
    phone: "+91 98765 43210",
    email: "rajesh@sunrisecafe.in",
    status: "New",
    productInterest: "Cardamom Tea Premix",
    createdAt: new Date().toISOString(),
  },
  {
    id: "2",
    name: "Anita Singh",
    businessName: "Corporate Vending Co.",
    phone: "+91 87654 32109",
    email: "anita@corp-vending.in",
    status: "Qualified",
    productInterest: "Masala Tea Premix",
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
  {
    id: "3",
    name: "Vikram Patel",
    businessName: "Patel Traders",
    phone: "+91 76543 21098",
    email: "vikram@pateltraders.in",
    status: "Converted",
    productInterest: "Lemongrass Tea Premix",
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
  },
  {
    id: "4",
    name: "Sunita Sharma",
    businessName: "Sharma Sweets & Snacks",
    phone: "+91 65432 10987",
    email: "sunita@sharmasweets.in",
    status: "Contacted",
    productInterest: "Ginger Tea Premix",
    createdAt: new Date(Date.now() - 86400000 * 1).toISOString(),
  }
];
