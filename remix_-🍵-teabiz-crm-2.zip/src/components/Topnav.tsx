import { motion } from "motion/react";
import { Leaf, UserPlus, FileText, Settings, BarChart2, Search } from "lucide-react";
import { cn } from "../utils";

interface TopnavProps {
  onAddLead: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export function Topnav({ onAddLead, searchQuery, onSearchChange }: TopnavProps) {
  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 shadow-sm border border-emerald-200">
              <Leaf className="w-6 h-6" />
            </div>
            <div className="flex flex-col">
              <span className="font-semibold text-lg text-emerald-900 leading-tight">ARIHANT'S Natural</span>
              <span className="text-xs text-stone-500 font-medium leading-tight tracking-wide">TEABIZ CRM</span>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
              <input 
                type="text" 
                placeholder="Search leads by name..." 
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="pl-9 pr-4 py-2 border border-stone-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 w-64 bg-stone-50 transition-shadow"
              />
            </div>
            <button 
              onClick={onAddLead}
              className="flex items-center gap-2 bg-emerald-700 hover:bg-emerald-800 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors shadow-sm"
            >
              <UserPlus className="w-4 h-4" />
              New Lead
            </button>
            <div className="w-px h-6 bg-stone-200 hidden sm:block"></div>
            <button className="text-stone-500 hover:text-emerald-700 transition-colors p-2 rounded-full hover:bg-stone-100">
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
