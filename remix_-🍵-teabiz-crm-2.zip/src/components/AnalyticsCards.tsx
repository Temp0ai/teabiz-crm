import { motion } from "motion/react";
import { Users, TrendingUp, Clock, CheckCircle } from "lucide-react";
import type { Lead } from "../types";

interface AnalyticsCardsProps {
  leads: Lead[];
}

export function AnalyticsCards({ leads }: AnalyticsCardsProps) {
  const totalLeads = leads.length;
  const converted = leads.filter(l => l.status === "Converted").length;
  const newLeads = leads.filter(l => l.status === "New").length;
  const conversionRate = totalLeads > 0 ? Math.round((converted / totalLeads) * 100) : 0;

  const stats = [
    {
      title: "Total Leads",
      value: totalLeads.toString(),
      trend: "+12%",
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
      borderColor: "border-blue-200"
    },
    {
      title: "Conversion Rate",
      value: `${conversionRate}%`,
      trend: "+4.2%",
      icon: TrendingUp,
      color: "text-emerald-600",
      bgColor: "bg-emerald-100",
      borderColor: "border-emerald-200"
    },
    {
      title: "New Inquiries",
      value: newLeads.toString(),
      trend: "-1",
      icon: Clock,
      color: "text-amber-600",
      bgColor: "bg-amber-100",
      borderColor: "border-amber-200"
    },
    {
      title: "Converted Clients",
      value: converted.toString(),
      trend: "+3",
      icon: CheckCircle,
      color: "text-indigo-600",
      bgColor: "bg-indigo-100",
      borderColor: "border-indigo-200"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, i) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1, duration: 0.4 }}
          className="bg-white p-6 rounded-xl border border-stone-200 shadow-sm flex items-start justify-between"
        >
          <div>
            <p className="text-sm font-medium text-stone-500 mb-1">{stat.title}</p>
            <h3 className="text-3xl font-semibold text-stone-900">{stat.value}</h3>
            <div className="mt-2 text-xs font-medium text-stone-500">
              <span className={stat.trend.startsWith("+") ? "text-emerald-600" : "text-rose-600"}>
                {stat.trend}
              </span> from last month
            </div>
          </div>
          <div className={`p-3 rounded-lg border ${stat.bgColor} ${stat.color} ${stat.borderColor}`}>
            <stat.icon className="w-5 h-5" />
          </div>
        </motion.div>
      ))}
    </div>
  );
}
