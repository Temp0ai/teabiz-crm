import { motion } from "motion/react";
import { MoreVertical, Mail, Phone, Building2, User } from "lucide-react";
import type { Lead } from "../types";
import { cn } from "../utils";

interface LeadListProps {
  leads: Lead[];
}

const statusColors: Record<string, string> = {
  New: "bg-blue-100 text-blue-700 border-blue-200",
  Contacted: "bg-amber-100 text-amber-700 border-amber-200",
  Qualified: "bg-indigo-100 text-indigo-700 border-indigo-200",
  Converted: "bg-emerald-100 text-emerald-700 border-emerald-200",
  Lost: "bg-rose-100 text-rose-700 border-rose-200"
};

export function LeadList({ leads }: LeadListProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden mb-8"
    >
      <div className="px-6 py-5 border-b border-stone-200 flex justify-between items-center bg-stone-50/50">
        <h3 className="text-lg font-semibold text-stone-900">Recent Leads</h3>
        <div className="text-sm text-emerald-700 font-medium hover:text-emerald-800 cursor-pointer">
          View all leads &rarr;
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-stone-50 border-b border-stone-200 text-stone-500 text-xs uppercase tracking-wider">
              <th className="px-6 py-4 font-medium">Contact</th>
              <th className="px-6 py-4 font-medium">Business</th>
              <th className="px-6 py-4 font-medium">Interest</th>
              <th className="px-6 py-4 font-medium">Status</th>
              <th className="px-6 py-4 font-medium">Added</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {leads.map((lead) => (
              <tr key={lead.id} className="hover:bg-stone-50/80 transition-colors group">
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="font-medium text-stone-900 flex items-center gap-2">
                       {lead.name}
                    </span>
                    <span className="text-xs text-stone-500 font-mono mt-1 flex items-center gap-1">
                       {lead.email}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="text-stone-900 font-medium">{lead.businessName}</span>
                    <span className="text-xs text-stone-500 mt-1">{lead.phone}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-stone-100 text-stone-700 border border-stone-200">
                    {lead.productInterest}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <span className={cn(
                    "inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border",
                    statusColors[lead.status] || "bg-stone-100 text-stone-700 border-stone-200"
                  )}>
                    {lead.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-stone-500">
                  {new Date(lead.createdAt).toLocaleDateString("en-IN", {
                    day: "numeric", month: "short", year: "numeric"
                  })}
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="text-stone-400 hover:text-emerald-600 transition-colors p-1 rounded hover:bg-emerald-50">
                    <MoreVertical className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
            {leads.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-8 text-center text-stone-500 text-sm">
                  No leads found. Add a new lead to get started.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
}
