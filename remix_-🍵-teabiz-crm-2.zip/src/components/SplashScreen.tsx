import { useEffect } from "react";
import { motion } from "motion/react";

interface SplashScreenProps {
  onFinish: () => void;
}

export function SplashScreen({ onFinish }: SplashScreenProps) {
  useEffect(() => {
    // Show the splash screen for 4 seconds to let animations complete
    const timer = setTimeout(() => {
      onFinish();
    }, 4000);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-[#F0EFE9]"
    >
      <style>{`
        .tea-stream {
          stroke-dasharray: 400;
          stroke-dashoffset: 400;
          animation: pourTea 2s ease-in-out 0.5s forwards; 
        }

        .steam path {
          opacity: 0;
          animation: riseSteam 3s infinite ease-in-out;
        }
        .steam path:nth-child(1) { animation-delay: 2.0s; }
        .steam path:nth-child(2) { animation-delay: 2.4s; }
        .steam path:nth-child(3) { animation-delay: 2.8s; }

        .brand-text {
          opacity: 0;
          transform: translateY(15px);
          animation: fadeInText 1s ease-out 2.5s forwards;
        }

        @keyframes pourTea {
          0% { stroke-dashoffset: 400; opacity: 1; }
          20% { stroke-dashoffset: 0; opacity: 1; } 
          70% { stroke-dashoffset: 0; opacity: 1; } 
          80% { opacity: 0; } 
          100% { opacity: 0; }
        }

        @keyframes riseSteam {
          0% { opacity: 0; transform: translateY(10px) scale(0.9); }
          50% { opacity: 0.6; }
          100% { opacity: 0; transform: translateY(-50px) scale(1.2); }
        }

        @keyframes fadeInText {
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
      <div className="relative flex h-[600px] w-[320px] items-center justify-center overflow-hidden rounded-[40px] bg-[#FAFAFA] shadow-[0_20px_50px_rgba(0,0,0,0.08),inset_0_0_0_6px_#FFFFFF]">
        <svg viewBox="0 0 320 600" width="100%" height="100%">
          <defs>
            <filter id="softShadow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur in="SourceAlpha" stdDeviation="6" />
              <feOffset dx="0" dy="15" result="offsetblur" />
              <feComponentTransfer>
                <feFuncA type="linear" slope="0.1" />
              </feComponentTransfer>
              <feMerge>
                <feMergeNode />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
            <filter id="steamBlur">
              <feGaussianBlur in="SourceGraphic" stdDeviation="3" />
            </filter>
            <linearGradient id="matteWhite" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#EAE6DF" />
            </linearGradient>
          </defs>

          <ellipse cx="160" cy="410" rx="60" ry="12" fill="rgba(0,0,0,0.06)" filter="url(#steamBlur)" />
          
          <line
            x1="160"
            y1="0"
            x2="160"
            y2="350"
            stroke="#8C5935"
            strokeWidth="6"
            className="tea-stream"
            strokeLinecap="round"
          />
          
          <path
            d="M 195 330 C 245 330, 245 385, 195 385"
            fill="none"
            stroke="url(#matteWhite)"
            strokeWidth="14"
            strokeLinecap="round"
            filter="url(#softShadow)"
          />
          
          <path
            d="M 110 310 L 110 390 Q 110 410 135 410 L 185 410 Q 210 410 210 390 L 210 310 Z"
            fill="url(#matteWhite)"
            filter="url(#softShadow)"
          />
          
          <g className="steam" filter="url(#steamBlur)">
            <path d="M 145 295 Q 130 250 155 200" fill="none" stroke="#FFFFFF" strokeWidth="8" strokeLinecap="round" />
            <path d="M 160 300 Q 185 260 155 210" fill="none" stroke="#FFFFFF" strokeWidth="12" strokeLinecap="round" />
            <path d="M 175 295 Q 160 260 185 220" fill="none" stroke="#FFFFFF" strokeWidth="6" strokeLinecap="round" />
          </g>

          <g className="brand-text">
            <text x="160" y="490" textAnchor="middle" fontSize="28" fontWeight="800" fill="#0A6B3B" letterSpacing="-0.5" fontFamily="Inter, sans-serif">
              Arihant's Natural
            </text>
            <text x="160" y="520" textAnchor="middle" fontSize="18" fontWeight="600" fill="#ED1C24" fontFamily="Georgia, serif" fontStyle="italic">
              Let's Brew
            </text>
            <text x="160" y="555" textAnchor="middle" fontSize="10" fontWeight="700" fill="#A0A0A0" letterSpacing="2" fontFamily="Inter, sans-serif">
              LOADING CRM
            </text>
          </g>
        </svg>
      </div>
    </motion.div>
  );
}
